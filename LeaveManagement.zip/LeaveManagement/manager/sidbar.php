<nav class="sidenav navbar navbar-vertical  fixed-left  navbar-expand-xs navbar-light bg-white" id="sidenav-main">
    <div class="scrollbar-inner">
      <!-- Brand -->
      <div class="sidenav-header  align-items-center">
        <a class="navbar-brand" href="javascript:void(0)">
          <h1 class="navbar-brand-img text-primary">Manger</h1>
        </a>
      </div>
      <div class="navbar-inner">
        <!-- Collapse -->
        <div class="collapse navbar-collapse" id="sidenav-collapse-main">
          <!-- Nav items -->
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link" href="./profile.php">
                <i class="ni ni-single-02 text-yellow"></i>
                <span class="nav-link-text">Profile</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="./leave_request.php">
                <i class="ni ni-bullet-list-67 text-default"></i>
                <span class="nav-link-text">leaves</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="./All_leave_Blance.php">
                <i class="ni ni-credit-card text-default"></i>
                <span class="nav-link-text">Employe Leave Balance</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="./EmployeesAdd.php">
                <i class="ni ni-badge text-default"></i>
                <span class="nav-link-text">Employe Add</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="./login.php">
                <i class="ni ni-key-25 text-info"></i>
                <span class="nav-link-text">Login</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="./register.php">
                <i class="ni ni-circle-08 text-pink"></i>
                <span class="nav-link-text">Register</span>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </nav>