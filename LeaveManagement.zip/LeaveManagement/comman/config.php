<?php 
     $con = mysqli_connect("localhost","root","","leave_management_db") or die("DataBase Is not Connected");
      session_start();
?>